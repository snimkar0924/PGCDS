This is the README.txt for a zip archive from http://cricsheet.org/
You can always find the most up-to-date version of this zip file at:
  http://cricsheet.org/downloads/ipl.zip

The data files contained in this zip file are version 0.6 files. You can
learn about the latest format at http://cricsheet.org/format/

The data files contained in this zip archive are listed below. The first
field is the start date of the match (for test matches or other multi-day
matches), or the actual date (for all other types of match). The second is
the type of match, either IPL, Test, ODI, ODM, T20, IT20 or MDM. The 3rd
field is the id of the data file, and the remainder of the line shows the
teams involved in the match.

2008-04-18 - IPL  - 335982 - Royal Challengers Bangalore vs Kolkata Knight Riders
2008-04-19 - IPL  - 335983 - Kings XI Punjab vs Chennai Super Kings
2008-04-19 - IPL  - 335984 - Delhi Daredevils vs Rajasthan Royals
2008-04-20 - IPL  - 335985 - Mumbai Indians vs Royal Challengers Bangalore
2008-04-20 - IPL  - 335986 - Kolkata Knight Riders vs Deccan Chargers
2008-04-21 - IPL  - 335987 - Rajasthan Royals vs Kings XI Punjab
2008-04-22 - IPL  - 335988 - Deccan Chargers vs Delhi Daredevils
2008-04-23 - IPL  - 335989 - Chennai Super Kings vs Mumbai Indians
2008-04-24 - IPL  - 335990 - Deccan Chargers vs Rajasthan Royals
2008-04-25 - IPL  - 335991 - Kings XI Punjab vs Mumbai Indians
2008-04-26 - IPL  - 335992 - Royal Challengers Bangalore vs Rajasthan Royals
2008-04-26 - IPL  - 335993 - Chennai Super Kings vs Kolkata Knight Riders
2008-04-27 - IPL  - 335994 - Mumbai Indians vs Deccan Chargers
2008-04-27 - IPL  - 335995 - Kings XI Punjab vs Delhi Daredevils
2008-04-28 - IPL  - 335996 - Royal Challengers Bangalore vs Chennai Super Kings
2008-04-29 - IPL  - 335997 - Kolkata Knight Riders vs Mumbai Indians
2008-04-30 - IPL  - 335998 - Delhi Daredevils vs Royal Challengers Bangalore
2008-05-01 - IPL  - 335999 - Deccan Chargers vs Kings XI Punjab
2008-05-01 - IPL  - 336000 - Rajasthan Royals vs Kolkata Knight Riders
2008-05-02 - IPL  - 336001 - Chennai Super Kings vs Delhi Daredevils
2008-05-03 - IPL  - 336003 - Kings XI Punjab vs Kolkata Knight Riders
2008-05-03 - IPL  - 336034 - Royal Challengers Bangalore vs Deccan Chargers
2008-05-04 - IPL  - 336004 - Mumbai Indians vs Delhi Daredevils
2008-05-04 - IPL  - 336005 - Rajasthan Royals vs Chennai Super Kings
2008-05-05 - IPL  - 336006 - Royal Challengers Bangalore vs Kings XI Punjab
2008-05-06 - IPL  - 336007 - Chennai Super Kings vs Deccan Chargers
2008-05-07 - IPL  - 336008 - Mumbai Indians vs Rajasthan Royals
2008-05-08 - IPL  - 336009 - Delhi Daredevils vs Chennai Super Kings
2008-05-08 - IPL  - 336010 - Kolkata Knight Riders vs Royal Challengers Bangalore
2008-05-09 - IPL  - 336011 - Rajasthan Royals vs Deccan Chargers
2008-05-10 - IPL  - 336013 - Chennai Super Kings vs Kings XI Punjab
2008-05-11 - IPL  - 336014 - Deccan Chargers vs Kolkata Knight Riders
2008-05-11 - IPL  - 336015 - Rajasthan Royals vs Delhi Daredevils
2008-05-12 - IPL  - 336016 - Kings XI Punjab vs Royal Challengers Bangalore
2008-05-13 - IPL  - 336017 - Kolkata Knight Riders vs Delhi Daredevils
2008-05-14 - IPL  - 336018 - Mumbai Indians vs Chennai Super Kings
2008-05-15 - IPL  - 336020 - Delhi Daredevils vs Deccan Chargers
2008-05-16 - IPL  - 336021 - Mumbai Indians vs Kolkata Knight Riders
2008-05-17 - IPL  - 336022 - Delhi Daredevils vs Kings XI Punjab
2008-05-17 - IPL  - 336023 - Rajasthan Royals vs Royal Challengers Bangalore
2008-05-18 - IPL  - 336024 - Deccan Chargers vs Mumbai Indians
2008-05-18 - IPL  - 336025 - Kolkata Knight Riders vs Chennai Super Kings
2008-05-19 - IPL  - 336026 - Royal Challengers Bangalore vs Delhi Daredevils
2008-05-20 - IPL  - 336027 - Kolkata Knight Riders vs Rajasthan Royals
2008-05-21 - IPL  - 336028 - Mumbai Indians vs Kings XI Punjab
2008-05-21 - IPL  - 336029 - Chennai Super Kings vs Royal Challengers Bangalore
2008-05-23 - IPL  - 336031 - Kings XI Punjab vs Deccan Chargers
2008-05-24 - IPL  - 336032 - Delhi Daredevils vs Mumbai Indians
2008-05-24 - IPL  - 336033 - Chennai Super Kings vs Rajasthan Royals
2008-05-25 - IPL  - 336002 - Deccan Chargers vs Royal Challengers Bangalore
2008-05-25 - IPL  - 336035 - Kolkata Knight Riders vs Kings XI Punjab
2008-05-26 - IPL  - 336036 - Rajasthan Royals vs Mumbai Indians
2008-05-27 - IPL  - 336037 - Deccan Chargers vs Chennai Super Kings
2008-05-28 - IPL  - 336012 - Royal Challengers Bangalore vs Mumbai Indians
2008-05-28 - IPL  - 336019 - Kings XI Punjab vs Rajasthan Royals
2008-05-30 - IPL  - 336038 - Delhi Daredevils vs Rajasthan Royals
2008-05-31 - IPL  - 336039 - Chennai Super Kings vs Kings XI Punjab
2008-06-01 - IPL  - 336040 - Chennai Super Kings vs Rajasthan Royals
2009-04-18 - IPL  - 392181 - Chennai Super Kings vs Mumbai Indians
2009-04-18 - IPL  - 392182 - Royal Challengers Bangalore vs Rajasthan Royals
2009-04-19 - IPL  - 392183 - Delhi Daredevils vs Kings XI Punjab
2009-04-19 - IPL  - 392184 - Deccan Chargers vs Kolkata Knight Riders
2009-04-20 - IPL  - 392185 - Royal Challengers Bangalore vs Chennai Super Kings
2009-04-21 - IPL  - 392186 - Kings XI Punjab vs Kolkata Knight Riders
2009-04-22 - IPL  - 392188 - Royal Challengers Bangalore vs Deccan Chargers
2009-04-23 - IPL  - 392189 - Chennai Super Kings vs Delhi Daredevils
2009-04-23 - IPL  - 392190 - Kolkata Knight Riders vs Rajasthan Royals
2009-04-24 - IPL  - 392191 - Royal Challengers Bangalore vs Kings XI Punjab
2009-04-25 - IPL  - 392192 - Deccan Chargers vs Mumbai Indians
2009-04-26 - IPL  - 392194 - Royal Challengers Bangalore vs Delhi Daredevils
2009-04-26 - IPL  - 392195 - Kings XI Punjab vs Rajasthan Royals
2009-04-27 - IPL  - 392196 - Chennai Super Kings vs Deccan Chargers
2009-04-27 - IPL  - 392197 - Kolkata Knight Riders vs Mumbai Indians
2009-04-28 - IPL  - 392198 - Delhi Daredevils vs Rajasthan Royals
2009-04-29 - IPL  - 392199 - Royal Challengers Bangalore vs Kolkata Knight Riders
2009-04-29 - IPL  - 392200 - Kings XI Punjab vs Mumbai Indians
2009-04-30 - IPL  - 392201 - Deccan Chargers vs Delhi Daredevils
2009-04-30 - IPL  - 392202 - Chennai Super Kings vs Rajasthan Royals
2009-05-01 - IPL  - 392203 - Kolkata Knight Riders vs Mumbai Indians
2009-05-01 - IPL  - 392204 - Royal Challengers Bangalore vs Kings XI Punjab
2009-05-02 - IPL  - 392205 - Deccan Chargers vs Rajasthan Royals
2009-05-02 - IPL  - 392206 - Chennai Super Kings vs Delhi Daredevils
2009-05-03 - IPL  - 392207 - Kings XI Punjab vs Kolkata Knight Riders
2009-05-03 - IPL  - 392208 - Royal Challengers Bangalore vs Mumbai Indians
2009-05-04 - IPL  - 392209 - Chennai Super Kings vs Deccan Chargers
2009-05-05 - IPL  - 392210 - Kings XI Punjab vs Rajasthan Royals
2009-05-05 - IPL  - 392211 - Delhi Daredevils vs Kolkata Knight Riders
2009-05-06 - IPL  - 392212 - Deccan Chargers vs Mumbai Indians
2009-05-07 - IPL  - 392213 - Royal Challengers Bangalore vs Rajasthan Royals
2009-05-07 - IPL  - 392214 - Chennai Super Kings vs Kings XI Punjab
2009-05-08 - IPL  - 392215 - Delhi Daredevils vs Mumbai Indians
2009-05-09 - IPL  - 392216 - Deccan Chargers vs Kings XI Punjab
2009-05-09 - IPL  - 392217 - Chennai Super Kings vs Rajasthan Royals
2009-05-10 - IPL  - 392218 - Royal Challengers Bangalore vs Mumbai Indians
2009-05-10 - IPL  - 392219 - Delhi Daredevils vs Kolkata Knight Riders
2009-05-11 - IPL  - 392220 - Deccan Chargers vs Rajasthan Royals
2009-05-12 - IPL  - 392221 - Royal Challengers Bangalore vs Kolkata Knight Riders
2009-05-12 - IPL  - 392222 - Kings XI Punjab vs Mumbai Indians
2009-05-13 - IPL  - 392223 - Deccan Chargers vs Delhi Daredevils
2009-05-14 - IPL  - 392224 - Royal Challengers Bangalore vs Chennai Super Kings
2009-05-14 - IPL  - 392225 - Mumbai Indians vs Rajasthan Royals
2009-05-15 - IPL  - 392226 - Delhi Daredevils vs Kings XI Punjab
2009-05-16 - IPL  - 392227 - Chennai Super Kings vs Mumbai Indians
2009-05-16 - IPL  - 392228 - Deccan Chargers vs Kolkata Knight Riders
2009-05-17 - IPL  - 392229 - Deccan Chargers vs Kings XI Punjab
2009-05-17 - IPL  - 392230 - Delhi Daredevils vs Rajasthan Royals
2009-05-18 - IPL  - 392231 - Chennai Super Kings vs Kolkata Knight Riders
2009-05-19 - IPL  - 392232 - Royal Challengers Bangalore vs Delhi Daredevils
2009-05-20 - IPL  - 392233 - Kolkata Knight Riders vs Rajasthan Royals
2009-05-20 - IPL  - 392234 - Chennai Super Kings vs Kings XI Punjab
2009-05-21 - IPL  - 392235 - Delhi Daredevils vs Mumbai Indians
2009-05-21 - IPL  - 392236 - Royal Challengers Bangalore vs Deccan Chargers
2009-05-22 - IPL  - 392237 - Delhi Daredevils vs Deccan Chargers
2009-05-23 - IPL  - 392238 - Royal Challengers Bangalore vs Chennai Super Kings
2009-05-24 - IPL  - 392239 - Royal Challengers Bangalore vs Deccan Chargers
2010-03-12 - IPL  - 419106 - Deccan Chargers vs Kolkata Knight Riders
2010-03-13 - IPL  - 419107 - Mumbai Indians vs Rajasthan Royals
2010-03-13 - IPL  - 419108 - Kings XI Punjab vs Delhi Daredevils
2010-03-14 - IPL  - 419109 - Kolkata Knight Riders vs Royal Challengers Bangalore
2010-03-14 - IPL  - 419110 - Chennai Super Kings vs Deccan Chargers
2010-03-15 - IPL  - 419111 - Rajasthan Royals vs Delhi Daredevils
2010-03-16 - IPL  - 419112 - Royal Challengers Bangalore vs Kings XI Punjab
2010-03-16 - IPL  - 419113 - Kolkata Knight Riders vs Chennai Super Kings
2010-03-17 - IPL  - 419114 - Delhi Daredevils vs Mumbai Indians
2010-03-18 - IPL  - 419115 - Royal Challengers Bangalore vs Rajasthan Royals
2010-03-19 - IPL  - 419116 - Delhi Daredevils vs Chennai Super Kings
2010-03-19 - IPL  - 419117 - Deccan Chargers vs Kings XI Punjab
2010-03-20 - IPL  - 419118 - Rajasthan Royals vs Kolkata Knight Riders
2010-03-20 - IPL  - 419119 - Mumbai Indians vs Royal Challengers Bangalore
2010-03-21 - IPL  - 419120 - Deccan Chargers vs Delhi Daredevils
2010-03-21 - IPL  - 419121 - Chennai Super Kings vs Kings XI Punjab
2010-03-22 - IPL  - 419122 - Mumbai Indians vs Kolkata Knight Riders
2010-03-23 - IPL  - 419123 - Royal Challengers Bangalore vs Chennai Super Kings
2010-03-24 - IPL  - 419124 - Kings XI Punjab vs Rajasthan Royals
2010-03-25 - IPL  - 419125 - Mumbai Indians vs Chennai Super Kings
2010-03-25 - IPL  - 419128 - Royal Challengers Bangalore vs Delhi Daredevils
2010-03-26 - IPL  - 419126 - Rajasthan Royals vs Deccan Chargers
2010-03-27 - IPL  - 419127 - Kings XI Punjab vs Kolkata Knight Riders
2010-03-28 - IPL  - 419129 - Rajasthan Royals vs Chennai Super Kings
2010-03-28 - IPL  - 419130 - Deccan Chargers vs Mumbai Indians
2010-03-29 - IPL  - 419131 - Delhi Daredevils vs Kolkata Knight Riders
2010-03-30 - IPL  - 419132 - Mumbai Indians vs Kings XI Punjab
2010-03-31 - IPL  - 419133 - Chennai Super Kings vs Royal Challengers Bangalore
2010-03-31 - IPL  - 419134 - Delhi Daredevils vs Rajasthan Royals
2010-04-01 - IPL  - 419135 - Kolkata Knight Riders vs Deccan Chargers
2010-04-02 - IPL  - 419136 - Kings XI Punjab vs Royal Challengers Bangalore
2010-04-03 - IPL  - 419137 - Chennai Super Kings vs Rajasthan Royals
2010-04-03 - IPL  - 419138 - Mumbai Indians vs Deccan Chargers
2010-04-04 - IPL  - 419139 - Kolkata Knight Riders vs Kings XI Punjab
2010-04-04 - IPL  - 419140 - Delhi Daredevils vs Royal Challengers Bangalore
2010-04-05 - IPL  - 419141 - Deccan Chargers vs Rajasthan Royals
2010-04-06 - IPL  - 419142 - Chennai Super Kings vs Mumbai Indians
2010-04-07 - IPL  - 419143 - Rajasthan Royals vs Kings XI Punjab
2010-04-07 - IPL  - 419144 - Kolkata Knight Riders vs Delhi Daredevils
2010-04-08 - IPL  - 419145 - Royal Challengers Bangalore vs Deccan Chargers
2010-04-09 - IPL  - 419146 - Kings XI Punjab vs Mumbai Indians
2010-04-10 - IPL  - 419147 - Deccan Chargers vs Chennai Super Kings
2010-04-10 - IPL  - 419148 - Royal Challengers Bangalore vs Kolkata Knight Riders
2010-04-11 - IPL  - 419149 - Delhi Daredevils vs Kings XI Punjab
2010-04-11 - IPL  - 419150 - Rajasthan Royals vs Mumbai Indians
2010-04-12 - IPL  - 419151 - Deccan Chargers vs Royal Challengers Bangalore
2010-04-13 - IPL  - 419152 - Mumbai Indians vs Delhi Daredevils
2010-04-13 - IPL  - 419153 - Chennai Super Kings vs Kolkata Knight Riders
2010-04-14 - IPL  - 419154 - Rajasthan Royals vs Royal Challengers Bangalore
2010-04-15 - IPL  - 419155 - Chennai Super Kings vs Delhi Daredevils
2010-04-16 - IPL  - 419156 - Kings XI Punjab vs Deccan Chargers
2010-04-17 - IPL  - 419157 - Royal Challengers Bangalore vs Mumbai Indians
2010-04-17 - IPL  - 419158 - Kolkata Knight Riders vs Rajasthan Royals
2010-04-18 - IPL  - 419159 - Kings XI Punjab vs Chennai Super Kings
2010-04-18 - IPL  - 419160 - Delhi Daredevils vs Deccan Chargers
2010-04-19 - IPL  - 419161 - Kolkata Knight Riders vs Mumbai Indians
2010-04-21 - IPL  - 419162 - Royal Challengers Bangalore vs Mumbai Indians
2010-04-22 - IPL  - 419163 - Chennai Super Kings vs Deccan Chargers
2010-04-24 - IPL  - 419164 - Royal Challengers Bangalore vs Deccan Chargers
2010-04-25 - IPL  - 419165 - Chennai Super Kings vs Mumbai Indians
2011-04-08 - IPL  - 501198 - Chennai Super Kings vs Kolkata Knight Riders
2011-04-09 - IPL  - 501199 - Deccan Chargers vs Rajasthan Royals
2011-04-09 - IPL  - 501200 - Kochi Tuskers Kerala vs Royal Challengers Bangalore
2011-04-10 - IPL  - 501201 - Delhi Daredevils vs Mumbai Indians
2011-04-10 - IPL  - 501202 - Pune Warriors vs Kings XI Punjab
2011-04-11 - IPL  - 501203 - Kolkata Knight Riders vs Deccan Chargers
2011-04-12 - IPL  - 501204 - Rajasthan Royals vs Delhi Daredevils
2011-04-12 - IPL  - 501205 - Royal Challengers Bangalore vs Mumbai Indians
2011-04-13 - IPL  - 501206 - Kings XI Punjab vs Chennai Super Kings
2011-04-13 - IPL  - 501207 - Pune Warriors vs Kochi Tuskers Kerala
2011-04-14 - IPL  - 501208 - Deccan Chargers vs Royal Challengers Bangalore
2011-04-15 - IPL  - 501209 - Rajasthan Royals vs Kolkata Knight Riders
2011-04-15 - IPL  - 501210 - Mumbai Indians vs Kochi Tuskers Kerala
2011-04-16 - IPL  - 501211 - Chennai Super Kings vs Royal Challengers Bangalore
2011-04-16 - IPL  - 501212 - Deccan Chargers vs Kings XI Punjab
2011-04-17 - IPL  - 501213 - Pune Warriors vs Delhi Daredevils
2011-04-17 - IPL  - 501214 - Kolkata Knight Riders vs Rajasthan Royals
2011-04-18 - IPL  - 501215 - Kochi Tuskers Kerala vs Chennai Super Kings
2011-04-19 - IPL  - 501216 - Delhi Daredevils vs Deccan Chargers
2011-04-20 - IPL  - 501218 - Mumbai Indians vs Pune Warriors
2011-04-20 - IPL  - 501219 - Kolkata Knight Riders vs Kochi Tuskers Kerala
2011-04-21 - IPL  - 501220 - Kings XI Punjab vs Rajasthan Royals
2011-04-22 - IPL  - 501221 - Mumbai Indians vs Chennai Super Kings
2011-04-22 - IPL  - 501222 - Kolkata Knight Riders vs Royal Challengers Bangalore
2011-04-23 - IPL  - 501223 - Delhi Daredevils vs Kings XI Punjab
2011-04-24 - IPL  - 501224 - Deccan Chargers vs Mumbai Indians
2011-04-24 - IPL  - 501225 - Rajasthan Royals vs Kochi Tuskers Kerala
2011-04-25 - IPL  - 501226 - Chennai Super Kings vs Pune Warriors
2011-04-26 - IPL  - 501227 - Delhi Daredevils vs Royal Challengers Bangalore
2011-04-27 - IPL  - 501228 - Pune Warriors vs Chennai Super Kings
2011-04-27 - IPL  - 501229 - Kochi Tuskers Kerala vs Deccan Chargers
2011-04-28 - IPL  - 501230 - Delhi Daredevils vs Kolkata Knight Riders
2011-04-29 - IPL  - 501231 - Rajasthan Royals vs Mumbai Indians
2011-04-29 - IPL  - 501232 - Royal Challengers Bangalore vs Pune Warriors
2011-04-30 - IPL  - 501233 - Kochi Tuskers Kerala vs Delhi Daredevils
2011-04-30 - IPL  - 501234 - Kolkata Knight Riders vs Kings XI Punjab
2011-05-01 - IPL  - 501235 - Rajasthan Royals vs Pune Warriors
2011-05-01 - IPL  - 501236 - Chennai Super Kings vs Deccan Chargers
2011-05-02 - IPL  - 501237 - Mumbai Indians vs Kings XI Punjab
2011-05-02 - IPL  - 501238 - Delhi Daredevils vs Kochi Tuskers Kerala
2011-05-03 - IPL  - 501239 - Deccan Chargers vs Kolkata Knight Riders
2011-05-04 - IPL  - 501240 - Chennai Super Kings vs Rajasthan Royals
2011-05-04 - IPL  - 501241 - Pune Warriors vs Mumbai Indians
2011-05-05 - IPL  - 501242 - Kochi Tuskers Kerala vs Kolkata Knight Riders
2011-05-05 - IPL  - 501243 - Deccan Chargers vs Delhi Daredevils
2011-05-06 - IPL  - 501244 - Royal Challengers Bangalore vs Kings XI Punjab
2011-05-07 - IPL  - 501245 - Kolkata Knight Riders vs Chennai Super Kings
2011-05-07 - IPL  - 501246 - Mumbai Indians vs Delhi Daredevils
2011-05-08 - IPL  - 501247 - Royal Challengers Bangalore vs Kochi Tuskers Kerala
2011-05-08 - IPL  - 501248 - Kings XI Punjab vs Pune Warriors
2011-05-09 - IPL  - 501249 - Rajasthan Royals vs Chennai Super Kings
2011-05-10 - IPL  - 501250 - Deccan Chargers vs Pune Warriors
2011-05-10 - IPL  - 501251 - Kings XI Punjab vs Mumbai Indians
2011-05-11 - IPL  - 501252 - Rajasthan Royals vs Royal Challengers Bangalore
2011-05-12 - IPL  - 501253 - Chennai Super Kings vs Delhi Daredevils
2011-05-13 - IPL  - 501254 - Kochi Tuskers Kerala vs Kings XI Punjab
2011-05-14 - IPL  - 501255 - Royal Challengers Bangalore vs Kolkata Knight Riders
2011-05-14 - IPL  - 501256 - Mumbai Indians vs Deccan Chargers
2011-05-15 - IPL  - 501257 - Kings XI Punjab vs Delhi Daredevils
2011-05-15 - IPL  - 501258 - Kochi Tuskers Kerala vs Rajasthan Royals
2011-05-16 - IPL  - 501259 - Pune Warriors vs Deccan Chargers
2011-05-17 - IPL  - 501260 - Kings XI Punjab vs Royal Challengers Bangalore
2011-05-18 - IPL  - 501261 - Chennai Super Kings vs Kochi Tuskers Kerala
2011-05-19 - IPL  - 501262 - Pune Warriors vs Kolkata Knight Riders
2011-05-20 - IPL  - 501263 - Mumbai Indians vs Rajasthan Royals
2011-05-21 - IPL  - 501264 - Kings XI Punjab vs Deccan Chargers
2011-05-21 - IPL  - 501265 - Delhi Daredevils vs Pune Warriors
2011-05-22 - IPL  - 501266 - Royal Challengers Bangalore vs Chennai Super Kings
2011-05-22 - IPL  - 501267 - Kolkata Knight Riders vs Mumbai Indians
2011-05-24 - IPL  - 501268 - Royal Challengers Bangalore vs Chennai Super Kings
2011-05-25 - IPL  - 501269 - Mumbai Indians vs Kolkata Knight Riders
2011-05-27 - IPL  - 501270 - Royal Challengers Bangalore vs Mumbai Indians
2011-05-28 - IPL  - 501271 - Chennai Super Kings vs Royal Challengers Bangalore
2012-04-04 - IPL  - 548306 - Chennai Super Kings vs Mumbai Indians
2012-04-05 - IPL  - 548307 - Kolkata Knight Riders vs Delhi Daredevils
2012-04-06 - IPL  - 548308 - Mumbai Indians vs Pune Warriors
2012-04-06 - IPL  - 548309 - Rajasthan Royals vs Kings XI Punjab
2012-04-07 - IPL  - 548310 - Royal Challengers Bangalore vs Delhi Daredevils
2012-04-07 - IPL  - 548311 - Deccan Chargers vs Chennai Super Kings
2012-04-08 - IPL  - 548312 - Rajasthan Royals vs Kolkata Knight Riders
2012-04-08 - IPL  - 548313 - Pune Warriors vs Kings XI Punjab
2012-04-09 - IPL  - 548314 - Deccan Chargers vs Mumbai Indians
2012-04-10 - IPL  - 548315 - Royal Challengers Bangalore vs Kolkata Knight Riders
2012-04-10 - IPL  - 548316 - Delhi Daredevils vs Chennai Super Kings
2012-04-11 - IPL  - 548317 - Mumbai Indians vs Rajasthan Royals
2012-04-12 - IPL  - 548318 - Chennai Super Kings vs Royal Challengers Bangalore
2012-04-12 - IPL  - 548319 - Kings XI Punjab vs Pune Warriors
2012-04-13 - IPL  - 548320 - Kolkata Knight Riders vs Rajasthan Royals
2012-04-14 - IPL  - 548322 - Pune Warriors vs Chennai Super Kings
2012-04-15 - IPL  - 548323 - Kolkata Knight Riders vs Kings XI Punjab
2012-04-15 - IPL  - 548324 - Royal Challengers Bangalore vs Rajasthan Royals
2012-04-16 - IPL  - 548325 - Mumbai Indians vs Delhi Daredevils
2012-04-17 - IPL  - 548326 - Rajasthan Royals vs Deccan Chargers
2012-04-17 - IPL  - 548327 - Royal Challengers Bangalore vs Pune Warriors
2012-04-18 - IPL  - 548328 - Kings XI Punjab vs Kolkata Knight Riders
2012-04-19 - IPL  - 548321 - Delhi Daredevils vs Deccan Chargers
2012-04-19 - IPL  - 548330 - Chennai Super Kings vs Pune Warriors
2012-04-20 - IPL  - 548331 - Kings XI Punjab vs Royal Challengers Bangalore
2012-04-21 - IPL  - 548332 - Chennai Super Kings vs Rajasthan Royals
2012-04-21 - IPL  - 548333 - Delhi Daredevils vs Pune Warriors
2012-04-22 - IPL  - 548334 - Mumbai Indians vs Kings XI Punjab
2012-04-22 - IPL  - 548335 - Deccan Chargers vs Kolkata Knight Riders
2012-04-23 - IPL  - 548336 - Rajasthan Royals vs Royal Challengers Bangalore
2012-04-24 - IPL  - 548337 - Pune Warriors vs Delhi Daredevils
2012-04-25 - IPL  - 548339 - Kings XI Punjab vs Mumbai Indians
2012-04-26 - IPL  - 548341 - Pune Warriors vs Deccan Chargers
2012-04-27 - IPL  - 548342 - Delhi Daredevils vs Mumbai Indians
2012-04-28 - IPL  - 548343 - Chennai Super Kings vs Kings XI Punjab
2012-04-28 - IPL  - 548344 - Kolkata Knight Riders vs Royal Challengers Bangalore
2012-04-29 - IPL  - 548345 - Delhi Daredevils vs Rajasthan Royals
2012-04-29 - IPL  - 548346 - Mumbai Indians vs Deccan Chargers
2012-04-30 - IPL  - 548347 - Chennai Super Kings vs Kolkata Knight Riders
2012-05-01 - IPL  - 548348 - Deccan Chargers vs Pune Warriors
2012-05-01 - IPL  - 548349 - Rajasthan Royals vs Delhi Daredevils
2012-05-02 - IPL  - 548350 - Royal Challengers Bangalore vs Kings XI Punjab
2012-05-03 - IPL  - 548351 - Pune Warriors vs Mumbai Indians
2012-05-04 - IPL  - 548352 - Chennai Super Kings vs Deccan Chargers
2012-05-05 - IPL  - 548353 - Kolkata Knight Riders vs Pune Warriors
2012-05-05 - IPL  - 548354 - Kings XI Punjab vs Rajasthan Royals
2012-05-06 - IPL  - 548355 - Mumbai Indians vs Chennai Super Kings
2012-05-06 - IPL  - 548356 - Royal Challengers Bangalore vs Deccan Chargers
2012-05-07 - IPL  - 548357 - Delhi Daredevils vs Kolkata Knight Riders
2012-05-08 - IPL  - 548358 - Pune Warriors vs Rajasthan Royals
2012-05-08 - IPL  - 548359 - Deccan Chargers vs Kings XI Punjab
2012-05-09 - IPL  - 548360 - Mumbai Indians vs Royal Challengers Bangalore
2012-05-10 - IPL  - 548329 - Deccan Chargers vs Delhi Daredevils
2012-05-10 - IPL  - 548361 - Rajasthan Royals vs Chennai Super Kings
2012-05-11 - IPL  - 548362 - Pune Warriors vs Royal Challengers Bangalore
2012-05-12 - IPL  - 548363 - Kolkata Knight Riders vs Mumbai Indians
2012-05-12 - IPL  - 548364 - Chennai Super Kings vs Delhi Daredevils
2012-05-13 - IPL  - 548365 - Rajasthan Royals vs Pune Warriors
2012-05-13 - IPL  - 548366 - Kings XI Punjab vs Deccan Chargers
2012-05-14 - IPL  - 548367 - Royal Challengers Bangalore vs Mumbai Indians
2012-05-14 - IPL  - 548368 - Kolkata Knight Riders vs Chennai Super Kings
2012-05-15 - IPL  - 548369 - Delhi Daredevils vs Kings XI Punjab
2012-05-16 - IPL  - 548370 - Mumbai Indians vs Kolkata Knight Riders
2012-05-17 - IPL  - 548371 - Kings XI Punjab vs Chennai Super Kings
2012-05-17 - IPL  - 548372 - Delhi Daredevils vs Royal Challengers Bangalore
2012-05-18 - IPL  - 548373 - Deccan Chargers vs Rajasthan Royals
2012-05-19 - IPL  - 548374 - Kings XI Punjab vs Delhi Daredevils
2012-05-19 - IPL  - 548375 - Pune Warriors vs Kolkata Knight Riders
2012-05-20 - IPL  - 548376 - Deccan Chargers vs Royal Challengers Bangalore
2012-05-20 - IPL  - 548377 - Rajasthan Royals vs Mumbai Indians
2012-05-22 - IPL  - 548378 - Delhi Daredevils vs Kolkata Knight Riders
2012-05-23 - IPL  - 548379 - Chennai Super Kings vs Mumbai Indians
2012-05-25 - IPL  - 548380 - Delhi Daredevils vs Chennai Super Kings
2012-05-27 - IPL  - 548381 - Kolkata Knight Riders vs Chennai Super Kings
2013-04-03 - IPL  - 597998 - Kolkata Knight Riders vs Delhi Daredevils
2013-04-04 - IPL  - 597999 - Royal Challengers Bangalore vs Mumbai Indians
2013-04-05 - IPL  - 598000 - Sunrisers Hyderabad vs Pune Warriors
2013-04-06 - IPL  - 598001 - Delhi Daredevils vs Rajasthan Royals
2013-04-06 - IPL  - 598002 - Chennai Super Kings vs Mumbai Indians
2013-04-07 - IPL  - 598003 - Pune Warriors vs Kings XI Punjab
2013-04-07 - IPL  - 598004 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2013-04-08 - IPL  - 598005 - Rajasthan Royals vs Kolkata Knight Riders
2013-04-09 - IPL  - 598006 - Mumbai Indians vs Delhi Daredevils
2013-04-09 - IPL  - 598048 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2013-04-10 - IPL  - 598007 - Kings XI Punjab vs Chennai Super Kings
2013-04-11 - IPL  - 598008 - Royal Challengers Bangalore vs Kolkata Knight Riders
2013-04-11 - IPL  - 598009 - Pune Warriors vs Rajasthan Royals
2013-04-12 - IPL  - 598010 - Delhi Daredevils vs Sunrisers Hyderabad
2013-04-13 - IPL  - 598011 - Mumbai Indians vs Pune Warriors
2013-04-13 - IPL  - 598012 - Chennai Super Kings vs Royal Challengers Bangalore
2013-04-14 - IPL  - 598013 - Kolkata Knight Riders vs Sunrisers Hyderabad
2013-04-14 - IPL  - 598014 - Rajasthan Royals vs Kings XI Punjab
2013-04-15 - IPL  - 598015 - Chennai Super Kings vs Pune Warriors
2013-04-16 - IPL  - 598016 - Kings XI Punjab vs Kolkata Knight Riders
2013-04-16 - IPL  - 598017 - Royal Challengers Bangalore vs Delhi Daredevils
2013-04-17 - IPL  - 598018 - Pune Warriors vs Sunrisers Hyderabad
2013-04-17 - IPL  - 598019 - Rajasthan Royals vs Mumbai Indians
2013-04-18 - IPL  - 598020 - Delhi Daredevils vs Chennai Super Kings
2013-04-19 - IPL  - 598021 - Sunrisers Hyderabad vs Kings XI Punjab
2013-04-20 - IPL  - 598022 - Kolkata Knight Riders vs Chennai Super Kings
2013-04-20 - IPL  - 598023 - Royal Challengers Bangalore vs Rajasthan Royals
2013-04-21 - IPL  - 598024 - Delhi Daredevils vs Mumbai Indians
2013-04-21 - IPL  - 598025 - Kings XI Punjab vs Pune Warriors
2013-04-22 - IPL  - 598026 - Chennai Super Kings vs Rajasthan Royals
2013-04-23 - IPL  - 598027 - Royal Challengers Bangalore vs Pune Warriors
2013-04-23 - IPL  - 598059 - Delhi Daredevils vs Kings XI Punjab
2013-04-24 - IPL  - 598029 - Kolkata Knight Riders vs Mumbai Indians
2013-04-25 - IPL  - 598030 - Chennai Super Kings vs Sunrisers Hyderabad
2013-04-26 - IPL  - 598031 - Kolkata Knight Riders vs Kings XI Punjab
2013-04-27 - IPL  - 598032 - Rajasthan Royals vs Sunrisers Hyderabad
2013-04-27 - IPL  - 598033 - Mumbai Indians vs Royal Challengers Bangalore
2013-04-28 - IPL  - 598034 - Chennai Super Kings vs Kolkata Knight Riders
2013-04-28 - IPL  - 598035 - Delhi Daredevils vs Pune Warriors
2013-04-29 - IPL  - 598036 - Rajasthan Royals vs Royal Challengers Bangalore
2013-04-29 - IPL  - 598037 - Mumbai Indians vs Kings XI Punjab
2013-04-30 - IPL  - 598038 - Pune Warriors vs Chennai Super Kings
2013-05-01 - IPL  - 598039 - Sunrisers Hyderabad vs Mumbai Indians
2013-05-01 - IPL  - 598040 - Delhi Daredevils vs Kolkata Knight Riders
2013-05-02 - IPL  - 598041 - Chennai Super Kings vs Kings XI Punjab
2013-05-02 - IPL  - 598042 - Pune Warriors vs Royal Challengers Bangalore
2013-05-03 - IPL  - 598043 - Kolkata Knight Riders vs Rajasthan Royals
2013-05-04 - IPL  - 598044 - Sunrisers Hyderabad vs Delhi Daredevils
2013-05-05 - IPL  - 598046 - Mumbai Indians vs Chennai Super Kings
2013-05-05 - IPL  - 598047 - Rajasthan Royals vs Pune Warriors
2013-05-06 - IPL  - 598064 - Kings XI Punjab vs Royal Challengers Bangalore
2013-05-07 - IPL  - 598049 - Rajasthan Royals vs Delhi Daredevils
2013-05-07 - IPL  - 598050 - Mumbai Indians vs Kolkata Knight Riders
2013-05-08 - IPL  - 598051 - Sunrisers Hyderabad vs Chennai Super Kings
2013-05-09 - IPL  - 598052 - Kings XI Punjab vs Rajasthan Royals
2013-05-09 - IPL  - 598053 - Pune Warriors vs Kolkata Knight Riders
2013-05-10 - IPL  - 598054 - Delhi Daredevils vs Royal Challengers Bangalore
2013-05-11 - IPL  - 598055 - Pune Warriors vs Mumbai Indians
2013-05-11 - IPL  - 598056 - Kings XI Punjab vs Sunrisers Hyderabad
2013-05-12 - IPL  - 598057 - Kolkata Knight Riders vs Royal Challengers Bangalore
2013-05-12 - IPL  - 598058 - Rajasthan Royals vs Chennai Super Kings
2013-05-13 - IPL  - 598060 - Mumbai Indians vs Sunrisers Hyderabad
2013-05-14 - IPL  - 598045 - Royal Challengers Bangalore vs Kings XI Punjab
2013-05-14 - IPL  - 598062 - Chennai Super Kings vs Delhi Daredevils
2013-05-15 - IPL  - 598061 - Kolkata Knight Riders vs Pune Warriors
2013-05-15 - IPL  - 598063 - Mumbai Indians vs Rajasthan Royals
2013-05-16 - IPL  - 598028 - Kings XI Punjab vs Delhi Daredevils
2013-05-17 - IPL  - 598065 - Sunrisers Hyderabad vs Rajasthan Royals
2013-05-18 - IPL  - 598066 - Kings XI Punjab vs Mumbai Indians
2013-05-18 - IPL  - 598068 - Royal Challengers Bangalore vs Chennai Super Kings
2013-05-19 - IPL  - 598067 - Pune Warriors vs Delhi Daredevils
2013-05-19 - IPL  - 598069 - Sunrisers Hyderabad vs Kolkata Knight Riders
2013-05-21 - IPL  - 598070 - Chennai Super Kings vs Mumbai Indians
2013-05-22 - IPL  - 598071 - Rajasthan Royals vs Sunrisers Hyderabad
2013-05-24 - IPL  - 598072 - Mumbai Indians vs Rajasthan Royals
2013-05-26 - IPL  - 598073 - Chennai Super Kings vs Mumbai Indians
2014-04-16 - IPL  - 729279 - Mumbai Indians vs Kolkata Knight Riders
2014-04-17 - IPL  - 729281 - Delhi Daredevils vs Royal Challengers Bangalore
2014-04-18 - IPL  - 729283 - Chennai Super Kings vs Kings XI Punjab
2014-04-18 - IPL  - 729285 - Sunrisers Hyderabad vs Rajasthan Royals
2014-04-19 - IPL  - 729287 - Royal Challengers Bangalore vs Mumbai Indians
2014-04-19 - IPL  - 729289 - Kolkata Knight Riders vs Delhi Daredevils
2014-04-20 - IPL  - 729291 - Rajasthan Royals vs Kings XI Punjab
2014-04-21 - IPL  - 729293 - Chennai Super Kings vs Delhi Daredevils
2014-04-22 - IPL  - 729295 - Kings XI Punjab vs Sunrisers Hyderabad
2014-04-23 - IPL  - 729297 - Rajasthan Royals vs Chennai Super Kings
2014-04-24 - IPL  - 729299 - Royal Challengers Bangalore vs Kolkata Knight Riders
2014-04-25 - IPL  - 729301 - Sunrisers Hyderabad vs Delhi Daredevils
2014-04-25 - IPL  - 729303 - Chennai Super Kings vs Mumbai Indians
2014-04-26 - IPL  - 729305 - Rajasthan Royals vs Royal Challengers Bangalore
2014-04-26 - IPL  - 729307 - Kolkata Knight Riders vs Kings XI Punjab
2014-04-27 - IPL  - 729309 - Delhi Daredevils vs Mumbai Indians
2014-04-27 - IPL  - 729311 - Sunrisers Hyderabad vs Chennai Super Kings
2014-04-28 - IPL  - 729313 - Kings XI Punjab vs Royal Challengers Bangalore
2014-04-29 - IPL  - 729315 - Kolkata Knight Riders vs Rajasthan Royals
2014-04-30 - IPL  - 729317 - Mumbai Indians vs Sunrisers Hyderabad
2014-05-02 - IPL  - 733971 - Chennai Super Kings vs Kolkata Knight Riders
2014-05-03 - IPL  - 733973 - Mumbai Indians vs Kings XI Punjab
2014-05-03 - IPL  - 733975 - Delhi Daredevils vs Rajasthan Royals
2014-05-04 - IPL  - 733977 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2014-05-05 - IPL  - 733979 - Rajasthan Royals vs Kolkata Knight Riders
2014-05-05 - IPL  - 733981 - Delhi Daredevils vs Chennai Super Kings
2014-05-06 - IPL  - 733983 - Mumbai Indians vs Royal Challengers Bangalore
2014-05-07 - IPL  - 733985 - Delhi Daredevils vs Kolkata Knight Riders
2014-05-07 - IPL  - 733987 - Kings XI Punjab vs Chennai Super Kings
2014-05-08 - IPL  - 733989 - Rajasthan Royals vs Sunrisers Hyderabad
2014-05-09 - IPL  - 733991 - Royal Challengers Bangalore vs Kings XI Punjab
2014-05-10 - IPL  - 733993 - Delhi Daredevils vs Sunrisers Hyderabad
2014-05-10 - IPL  - 733995 - Mumbai Indians vs Chennai Super Kings
2014-05-11 - IPL  - 733997 - Kings XI Punjab vs Kolkata Knight Riders
2014-05-11 - IPL  - 733999 - Royal Challengers Bangalore vs Rajasthan Royals
2014-05-12 - IPL  - 734001 - Sunrisers Hyderabad vs Mumbai Indians
2014-05-13 - IPL  - 734003 - Chennai Super Kings vs Rajasthan Royals
2014-05-13 - IPL  - 734005 - Royal Challengers Bangalore vs Delhi Daredevils
2014-05-14 - IPL  - 734007 - Sunrisers Hyderabad vs Kings XI Punjab
2014-05-14 - IPL  - 734009 - Kolkata Knight Riders vs Mumbai Indians
2014-05-15 - IPL  - 734011 - Rajasthan Royals vs Delhi Daredevils
2014-05-18 - IPL  - 734013 - Chennai Super Kings vs Royal Challengers Bangalore
2014-05-18 - IPL  - 734015 - Sunrisers Hyderabad vs Kolkata Knight Riders
2014-05-19 - IPL  - 734017 - Rajasthan Royals vs Mumbai Indians
2014-05-19 - IPL  - 734019 - Delhi Daredevils vs Kings XI Punjab
2014-05-20 - IPL  - 734021 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2014-05-20 - IPL  - 734023 - Kolkata Knight Riders vs Chennai Super Kings
2014-05-21 - IPL  - 734025 - Kings XI Punjab vs Mumbai Indians
2014-05-22 - IPL  - 734027 - Kolkata Knight Riders vs Royal Challengers Bangalore
2014-05-22 - IPL  - 734029 - Chennai Super Kings vs Sunrisers Hyderabad
2014-05-23 - IPL  - 734031 - Mumbai Indians vs Delhi Daredevils
2014-05-23 - IPL  - 734033 - Kings XI Punjab vs Rajasthan Royals
2014-05-24 - IPL  - 734035 - Royal Challengers Bangalore vs Chennai Super Kings
2014-05-24 - IPL  - 734037 - Kolkata Knight Riders vs Sunrisers Hyderabad
2014-05-25 - IPL  - 734039 - Kings XI Punjab vs Delhi Daredevils
2014-05-25 - IPL  - 734041 - Mumbai Indians vs Rajasthan Royals
2014-05-27 - IPL  - 734043 - Kings XI Punjab vs Kolkata Knight Riders
2014-05-28 - IPL  - 734045 - Chennai Super Kings vs Mumbai Indians
2014-05-30 - IPL  - 734047 - Chennai Super Kings vs Kings XI Punjab
2014-06-01 - IPL  - 734049 - Kolkata Knight Riders vs Kings XI Punjab
2015-04-08 - IPL  - 829705 - Kolkata Knight Riders vs Mumbai Indians
2015-04-09 - IPL  - 829707 - Chennai Super Kings vs Delhi Daredevils
2015-04-10 - IPL  - 829709 - Kings XI Punjab vs Rajasthan Royals
2015-04-11 - IPL  - 829711 - Chennai Super Kings vs Sunrisers Hyderabad
2015-04-11 - IPL  - 829713 - Kolkata Knight Riders vs Royal Challengers Bangalore
2015-04-12 - IPL  - 829715 - Delhi Daredevils vs Rajasthan Royals
2015-04-12 - IPL  - 829717 - Mumbai Indians vs Kings XI Punjab
2015-04-13 - IPL  - 829719 - Royal Challengers Bangalore vs Sunrisers Hyderabad
2015-04-14 - IPL  - 829721 - Rajasthan Royals vs Mumbai Indians
2015-04-15 - IPL  - 829725 - Kings XI Punjab vs Delhi Daredevils
2015-04-16 - IPL  - 829727 - Sunrisers Hyderabad vs Rajasthan Royals
2015-04-17 - IPL  - 829729 - Mumbai Indians vs Chennai Super Kings
2015-04-18 - IPL  - 829731 - Sunrisers Hyderabad vs Delhi Daredevils
2015-04-18 - IPL  - 829733 - Kings XI Punjab vs Kolkata Knight Riders
2015-04-19 - IPL  - 829735 - Rajasthan Royals vs Chennai Super Kings
2015-04-19 - IPL  - 829737 - Royal Challengers Bangalore vs Mumbai Indians
2015-04-20 - IPL  - 829739 - Delhi Daredevils vs Kolkata Knight Riders
2015-04-21 - IPL  - 829741 - Rajasthan Royals vs Kings XI Punjab
2015-04-22 - IPL  - 829743 - Sunrisers Hyderabad vs Kolkata Knight Riders
2015-04-22 - IPL  - 829745 - Royal Challengers Bangalore vs Chennai Super Kings
2015-04-23 - IPL  - 829747 - Delhi Daredevils vs Mumbai Indians
2015-04-24 - IPL  - 829749 - Rajasthan Royals vs Royal Challengers Bangalore
2015-04-25 - IPL  - 829751 - Mumbai Indians vs Sunrisers Hyderabad
2015-04-25 - IPL  - 829753 - Chennai Super Kings vs Kings XI Punjab
2015-04-26 - IPL  - 829757 - Delhi Daredevils vs Royal Challengers Bangalore
2015-04-27 - IPL  - 829759 - Kings XI Punjab vs Sunrisers Hyderabad
2015-04-28 - IPL  - 829765 - Chennai Super Kings vs Kolkata Knight Riders
2015-04-29 - IPL  - 829763 - Royal Challengers Bangalore vs Rajasthan Royals
2015-04-30 - IPL  - 829723 - Kolkata Knight Riders vs Chennai Super Kings
2015-05-01 - IPL  - 829767 - Delhi Daredevils vs Kings XI Punjab
2015-05-01 - IPL  - 829769 - Mumbai Indians vs Rajasthan Royals
2015-05-02 - IPL  - 829771 - Royal Challengers Bangalore vs Kolkata Knight Riders
2015-05-02 - IPL  - 829773 - Sunrisers Hyderabad vs Chennai Super Kings
2015-05-03 - IPL  - 829775 - Kings XI Punjab vs Mumbai Indians
2015-05-03 - IPL  - 829777 - Rajasthan Royals vs Delhi Daredevils
2015-05-04 - IPL  - 829779 - Chennai Super Kings vs Royal Challengers Bangalore
2015-05-04 - IPL  - 829781 - Kolkata Knight Riders vs Sunrisers Hyderabad
2015-05-05 - IPL  - 829783 - Mumbai Indians vs Delhi Daredevils
2015-05-06 - IPL  - 829785 - Royal Challengers Bangalore vs Kings XI Punjab
2015-05-07 - IPL  - 829761 - Kolkata Knight Riders vs Delhi Daredevils
2015-05-07 - IPL  - 829787 - Rajasthan Royals vs Sunrisers Hyderabad
2015-05-08 - IPL  - 829789 - Chennai Super Kings vs Mumbai Indians
2015-05-09 - IPL  - 829791 - Kolkata Knight Riders vs Kings XI Punjab
2015-05-09 - IPL  - 829793 - Delhi Daredevils vs Sunrisers Hyderabad
2015-05-10 - IPL  - 829795 - Mumbai Indians vs Royal Challengers Bangalore
2015-05-10 - IPL  - 829797 - Chennai Super Kings vs Rajasthan Royals
2015-05-11 - IPL  - 829799 - Sunrisers Hyderabad vs Kings XI Punjab
2015-05-12 - IPL  - 829801 - Delhi Daredevils vs Chennai Super Kings
2015-05-13 - IPL  - 829803 - Kings XI Punjab vs Royal Challengers Bangalore
2015-05-14 - IPL  - 829805 - Mumbai Indians vs Kolkata Knight Riders
2015-05-15 - IPL  - 829807 - Sunrisers Hyderabad vs Royal Challengers Bangalore
2015-05-16 - IPL  - 829809 - Kings XI Punjab vs Chennai Super Kings
2015-05-16 - IPL  - 829811 - Rajasthan Royals vs Kolkata Knight Riders
2015-05-17 - IPL  - 829813 - Royal Challengers Bangalore vs Delhi Daredevils
2015-05-17 - IPL  - 829815 - Sunrisers Hyderabad vs Mumbai Indians
2015-05-19 - IPL  - 829817 - Chennai Super Kings vs Mumbai Indians
2015-05-20 - IPL  - 829819 - Royal Challengers Bangalore vs Rajasthan Royals
2015-05-22 - IPL  - 829821 - Chennai Super Kings vs Royal Challengers Bangalore
2015-05-24 - IPL  - 829823 - Mumbai Indians vs Chennai Super Kings